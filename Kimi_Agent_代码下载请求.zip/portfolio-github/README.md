# Aashis Sapkota - Portfolio

A modern, responsive portfolio website for IT & Cybersecurity Student built with React, TypeScript, Tailwind CSS, and shadcn/ui.

![Portfolio Screenshot](./screenshot.png)

## 🌟 Features

- **Modern Design**: Clean, professional UI with gradient accents
- **Fully Responsive**: Works on desktop, tablet, and mobile
- **Admin Panel**: Secure login to edit content
- **Image Uploads**: Add photos to profile, projects, education & experience
- **Data Persistence**: All changes saved to localStorage
- **Secure Authentication**: Two-factor auth with session timeout
- **Smooth Animations**: Hover effects and transitions

## 🚀 Live Demo

[View Live Site](https://yourusername.github.io/aashis-portfolio)

## 🛠️ Tech Stack

- **Framework**: React + TypeScript + Vite
- **Styling**: Tailwind CSS
- **Components**: shadcn/ui (40+ pre-built components)
- **Icons**: Lucide React
- **Notifications**: Sonner

## 📦 Installation

```bash
# Clone the repository
git clone https://github.com/yourusername/aashis-portfolio.git

# Navigate to project folder
cd aashis-portfolio

# Install dependencies
npm install

# Start development server
npm run dev

# Build for production
npm run build
```

## 🔐 Admin Access

1. Click the **shield icon** (top right)
2. Enter password: `Admin@2024!`
3. Enter the verification code shown
4. Edit content and click **Save All**

## 📝 Customization

### Personal Info
Edit in Admin Panel:
- Name, Title, Email
- About Me section
- Social Links (LinkedIn, GitHub, Twitter)

### Content Sections
- **Skills**: Add/edit with progress bars
- **Experience**: Add work history with images
- **Education**: Add degrees with images
- **Projects**: Showcase projects with images

## 📁 Project Structure

```
├── src/
│   ├── App.tsx          # Main application
│   ├── App.css          # Custom styles
│   ├── components/ui/   # shadcn/ui components
│   └── ...
├── .github/workflows/   # GitHub Actions for deployment
├── package.json         # Dependencies
└── README.md           # This file
```

## 🌐 Deployment

### GitHub Pages (Free)

1. Push code to GitHub
2. Go to Settings → Pages
3. Source: GitHub Actions
4. The workflow will auto-deploy on every push

### Other Platforms

- **Vercel**: Import GitHub repo
- **Netlify**: Drag & drop `dist` folder
- **Firebase**: Use Firebase CLI

## 📄 License

MIT License - feel free to use and modify!

## 🤝 Contact

- Email: sapkotaaashis62@gmail.com
- LinkedIn: [Your LinkedIn]
- GitHub: [Your GitHub]

---

Made with ❤️ by Aashis Sapkota
